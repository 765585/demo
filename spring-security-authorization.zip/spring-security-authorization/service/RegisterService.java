package com.example.om.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.om.entity.Model;
import com.example.om.repository.RegisterRepository;
import java.util.Optional;

@Service
public class RegisterService {
	@Autowired
	private static RegisterRepository repository;

	public String savedata(Model data) {
		repository.save(data);
		return "User registered";
	}
	public List<Model> getUsers() {
		return repository.findAll();
	}

	public String deleteUser(int id) {
		Optional<Model> userdetails = repository.findById(id);
		if (userdetails.isPresent()) {
			repository.deleteById(id);
			return "User deleted succesfully";
		} else
			return "Invalid userid";
				
		

	}

	public String updateData(int id, Model data) {
		Optional<Model> userdetails = repository.findById(id);
		if (userdetails.isPresent()) {
			repository.save(data);
			return "updated";
		} else
			return "Invalid userid";
		
	}
	public Optional<Model> getById(int id) {
		
		return repository.findById(id);
	}
	public static void saveUser(Model model) {
		repository.save(model);
		
	}
}
