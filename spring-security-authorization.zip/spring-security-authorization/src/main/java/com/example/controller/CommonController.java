package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.om.entity.Model;
import com.example.om.service.UserService;


@Controller
public class CommonController {
	@Autowired
	UserService userServices;
	
	@RequestMapping(value={"/","/login","{invalid}"}, method=RequestMethod.GET)
	public ModelAndView index(){
		return new ModelAndView("index");
	}
//	@RequestMapping(value= {"/"}, method=RequestMethod.GET)
//	public ModelAndView indexPage(){
//		return new ModelAndView("index");
//	}
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public ModelAndView registerUser(){
		System.out.println("register");
		ModelAndView mav = new ModelAndView("user-register","user",new Model());
		return mav;
		
	}
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public ModelAndView submitNewRegisterUser(@ModelAttribute Model user){
		ModelAndView mav = new ModelAndView();
		userServices.create(user);
		mav.setViewName("redirect:/index");
		return mav;
		
	}
}
