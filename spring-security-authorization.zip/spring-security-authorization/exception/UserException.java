package com.example.om.exception;

@SuppressWarnings("serial")
public class UserException extends Exception{
	
	
}
